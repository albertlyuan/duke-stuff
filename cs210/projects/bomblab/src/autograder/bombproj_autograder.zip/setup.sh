#!/usr/bin/env bash

apt-get install -y python3 python3-pip
apt-get install -y valgrind
apt-get install -y curl
apt-get install -y strace

